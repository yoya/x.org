#define VERSIONNUMB "1.0" 
#define VERSIONNAME "crock -- initial release"
