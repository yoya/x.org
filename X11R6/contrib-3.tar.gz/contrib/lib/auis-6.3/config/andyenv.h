/* ********************************************************************** *\
 *         Copyright IBM Corporation 1988,1991 - All Rights Reserved      *
 *        For full copyright information see:'andrew/config/COPYRITE'     *
\* ********************************************************************** */
#ifndef	_ANDREWENV_
#define _ANDREWENV_
#include <andrewos.h>
#endif /* _ANDREWENV_ */
