/* ********************************************************************** *\
 *         Copyright IBM Corporation 1988,1991 - All Rights Reserved      *
 *        For full copyright information see:'andrew/config/COPYRITE'     *
\* ********************************************************************** */
static char *pmalloc_rcsid = "$Header: /afs/cs.cmu.edu/project/atk-dist/auis-6.3/overhead/malloc/RCS/pmalloc.c,v 2.5 1991/09/12 17:17:16 bobg R6tape $";

#define IDENTIFY
#include "malloc.ci"
