/* ********************************************************************** *\
 *         Copyright IBM Corporation 1988,1991 - All Rights Reserved      *
 *        For full copyright information see:'andrew/config/COPYRITE'     *
\* ********************************************************************** */
static char *malloc_rcsid = "$Header: /afs/cs.cmu.edu/project/atk-dist/auis-6.3/overhead/malloc/RCS/malloc.c,v 2.5 1991/09/12 17:16:50 bobg R6tape $";

#include "malloc.ci"
