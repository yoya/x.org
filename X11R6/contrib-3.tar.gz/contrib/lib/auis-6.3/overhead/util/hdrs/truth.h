/* ********************************************************************** *\
 *         Copyright IBM Corporation 1988,1991 - All Rights Reserved      *
 *        For full copyright information see:'andrew/config/COPYRITE'     *
\* ********************************************************************** */
/* $Header: /afs/cs.cmu.edu/project/atk-dist/auis-6.3/overhead/util/hdrs/RCS/truth.h,v 2.4 1992/07/24 23:09:24 gk5g R6tape $ */

#ifndef TRUE
#define	TRUE	1
#define	FALSE	0
#endif

#ifndef NULL
#define	NULL	0
#endif
