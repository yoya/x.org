/* ********************************************************************** *\
 *         Copyright IBM Corporation 1988,1991 - All Rights Reserved      *
 *        For full copyright information see:'andrew/config/COPYRITE'     *
\* ********************************************************************** */
/* $Header: /afs/cs.cmu.edu/project/atk-dist/auis-6.3/overhead/cmenu/RCS/wormimg.h,v 2.4 1991/09/12 20:22:58 bobg R6tape $ */
/* $Source: /afs/cs.cmu.edu/project/atk-dist/auis-6.3/overhead/cmenu/RCS/wormimg.h,v $ */

#define worm_width 11
#define worm_height 11
static char worm_bits[] = {
   0xf8, 0x00, 0xae, 0x03, 0x02, 0x02, 0x73, 0x06, 0xf9, 0x04, 0xfb, 0x06,
   0xf9, 0x04, 0x73, 0x06, 0x02, 0x02, 0xae, 0x03, 0xf8, 0x00, 0x00, 0x00,
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
