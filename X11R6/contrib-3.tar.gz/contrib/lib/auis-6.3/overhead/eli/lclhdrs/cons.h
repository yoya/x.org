/* ********************************************************************** *\
 *         Copyright IBM Corporation 1988,1991 - All Rights Reserved      *
 *        For full copyright information see:'andrew/config/COPYRITE'     *
\* ********************************************************************** */

/*
 * $Header: /afs/cs.cmu.edu/project/atk-dist/auis-6.3/overhead/eli/lclhdrs/RCS/cons.h,v 2.4 1991/09/12 20:24:05 bobg R6tape $ 
 *
 * $Source: /afs/cs.cmu.edu/project/atk-dist/auis-6.3/overhead/eli/lclhdrs/RCS/cons.h,v $ 
 */

#include  <eli.h>
