/* ********************************************************************** *\
 *         Copyright IBM Corporation 1988,1991 - All Rights Reserved      *
 *        For full copyright information see:'andrew/config/COPYRITE'     *
\* ********************************************************************** */

/*
 * $Header: /afs/cs.cmu.edu/project/atk-dist/auis-6.3/overhead/eli/lclhdrs/RCS/str.h,v 2.4 1991/09/12 20:25:06 bobg R6tape $ 
 *
 * $Source: /afs/cs.cmu.edu/project/atk-dist/auis-6.3/overhead/eli/lclhdrs/RCS/str.h,v $ 
 */

#include  <eli.h>
