/* ********************************************************************** *\
 *         Copyright IBM Corporation 1988,1991 - All Rights Reserved      *
 *        For full copyright information see:'andrew/config/COPYRITE'     *
\* ********************************************************************** */

/*
 * $Header: /afs/cs.cmu.edu/project/atk-dist/auis-6.3/overhead/eli/lclhdrs/RCS/ecommon.h,v 2.5 1994/05/04 19:49:56 rr2b Exp $ 
 *
 * $Source: /afs/cs.cmu.edu/project/atk-dist/auis-6.3/overhead/eli/lclhdrs/RCS/ecommon.h,v $ 
 */

#include  <eli.h>
