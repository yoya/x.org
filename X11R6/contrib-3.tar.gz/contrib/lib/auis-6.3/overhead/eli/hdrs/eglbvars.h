/* ********************************************************************** *\
 *         Copyright IBM Corporation 1988,1991 - All Rights Reserved      *
 *        For full copyright information see:'andrew/config/COPYRITE'     *
\* ********************************************************************** */

/*
 * $Header: /afs/cs.cmu.edu/project/atk-dist/auis-6.3/overhead/eli/hdrs/RCS/eglbvars.h,v 2.4 1991/09/12 20:23:35 bobg R6tape $ 
 *
 * $Source: /afs/cs.cmu.edu/project/atk-dist/auis-6.3/overhead/eli/hdrs/RCS/eglbvars.h,v $ 
 */

extern EliProcessInfo_t EliProcessInfo;
