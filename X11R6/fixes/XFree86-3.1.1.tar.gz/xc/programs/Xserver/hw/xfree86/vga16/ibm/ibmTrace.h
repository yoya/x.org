/* $XConsortium: ibmTrace.h,v 1.1 94/03/28 21:34:53 dpw Exp $ */

#define TRACE(x) /* empty */
