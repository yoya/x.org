/* $XConsortium: vgaData.c,v 1.1 94/03/28 21:39:08 dpw Exp $ */
