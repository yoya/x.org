/* $XConsortium: ppcSinTab.c,v 1.1 94/03/28 21:38:23 dpw Exp $ */
