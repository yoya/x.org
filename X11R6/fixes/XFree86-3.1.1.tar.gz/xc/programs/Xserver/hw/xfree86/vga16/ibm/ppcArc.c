/* $XConsortium: ppcArc.c,v 1.1 94/03/28 21:35:33 dpw Exp $ */
