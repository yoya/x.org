/* $XConsortium: ppcProcs.h,v 1.1 94/03/28 21:37:40 dpw Exp $ */
