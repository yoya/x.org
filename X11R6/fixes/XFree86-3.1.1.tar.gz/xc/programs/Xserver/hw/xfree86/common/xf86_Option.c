/* $XConsortium: xf86_Option.c,v 1.1 94/03/28 21:24:19 dpw Exp $ */
/*
 *
 * The purpose of this file is to initialise the xf86_OptionTab[] which
 * is setup in xf86_Option.h
 */

#define INIT_OPTIONS
#define _NO_XF86_PROTOTYPES

#include "X.h"
#include "os.h"
#include "xf86.h"

