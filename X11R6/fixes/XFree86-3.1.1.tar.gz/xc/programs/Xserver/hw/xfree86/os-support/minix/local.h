/* $XFree86: xc/programs/Xserver/hw/xfree86/os-support/minix/local.h,v 3.0 1994/05/08 05:23:46 dawes Exp $ */
/*
local.h

Local definitions for the minix os libary

Created:	19 April, 1994 by Philip Homburg <philip@cs.vu.nl>
*/

extern char *xf86VideoBaseRaw;
extern char *xf86VideoBase;
