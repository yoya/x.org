kterm|kterm kanji terminal emulator (X window system),
	hs, eslok, tsl=\E[?E\E[?%i%dT, fs=\E[?F, ds=\E[?H,
	sc=\E7, rc=\E8, csr=\E[%i%p1%d;%p2%dr,
	use=xterm,
