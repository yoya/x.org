vk|kterm|kterm kanji terminal emurator (X window system):\
	:hs:es:ts=\E[?E\E[?%i%dT:fs=\E[?F:ds=\E[?H:\
	:KJ:sc=\E7:rc=\E8:cs=\E[%i%d;%dr:TY=ascii:tc=xterm:
