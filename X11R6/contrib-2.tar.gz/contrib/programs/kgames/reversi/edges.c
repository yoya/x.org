/*
 *	edgescores.c
 */

#include	"reversi.h"

scoreT edgescores [4][4][4][4][4][4][4][4] = {
# include "edges.out"
};
