# define static
# include	"_go"
# include	"go_label"
# include	"go_mask"
