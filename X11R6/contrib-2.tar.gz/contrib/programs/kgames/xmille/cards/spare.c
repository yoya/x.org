# define static
# include	"_spare"
# include	"spare_label"
# include	"spare_mask"
