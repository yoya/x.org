# define static
# include "_out"
# include "out_label"
# include "out_mask"
