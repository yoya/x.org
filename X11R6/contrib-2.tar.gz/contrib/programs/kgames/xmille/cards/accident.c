# define static 
# include "_accident"
# include "accident_label"
# include "accident_mask"

