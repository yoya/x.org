# define static
# include	"_repairs"
# include	"repairs_label"
# include	"repairs_mask"
