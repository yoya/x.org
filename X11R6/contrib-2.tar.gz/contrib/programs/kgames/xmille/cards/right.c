# define static
# include	"_right"
# include	"right_label"
# include	"right_mask"
