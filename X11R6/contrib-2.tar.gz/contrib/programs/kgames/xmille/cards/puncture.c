# define static
# include 	"_puncture"
# include	"puncture_mask"
# include	"puncture_label"
