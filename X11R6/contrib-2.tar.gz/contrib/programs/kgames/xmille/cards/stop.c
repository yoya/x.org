# define static
# include	"_stop"
# include	"stop_label"
# include	"stop_mask"
