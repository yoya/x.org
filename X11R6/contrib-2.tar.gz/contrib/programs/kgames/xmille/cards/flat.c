# define static
# include	"_flat"
# include	"flat_label"
# include	"flat_mask"
