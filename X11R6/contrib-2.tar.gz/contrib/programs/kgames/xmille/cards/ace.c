# define static
# include	"_ace"
# include	"ace_label"
# include	"ace_mask"
