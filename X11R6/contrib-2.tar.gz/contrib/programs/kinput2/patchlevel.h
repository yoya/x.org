#define KINPUT2_VERSION "version 2.0"
#define DATE "$Date: 1994/06/06 07:22:37 $"
#define PATCHLEVEL 0
